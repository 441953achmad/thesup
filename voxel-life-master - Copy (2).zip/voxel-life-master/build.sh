#!/bin/sh
browserify index.js -o bundle.js -dv
